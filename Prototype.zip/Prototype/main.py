import argparse
import socket

from backend import create_app


def wifi_address():
    """The address of this computer on the local network, so phones can open the site."""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as probe:
            probe.connect(("10.255.255.255", 1))     # nothing is sent; this just picks the network card
            return probe.getsockname()[0]
    except OSError:
        return None


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Endfield's Cafe seat system")
    parser.add_argument("--port", type=int, default=5000, help="website port (default 5000)")
    parser.add_argument("--host", default="127.0.0.1",
                        help="use 0.0.0.0 to let phones on your Wi-Fi open the site")
    parser.add_argument("--fresh", action="store_true",
                        help="ignore the saved line and tables and start over with the demo crowd")
    parser.add_argument("--empty", action="store_true",
                        help="ignore the saved line and tables and start with every table free")
    args = parser.parse_args()

    app = create_app(demo=not args.empty, fresh=args.fresh or args.empty)
    print(f"Customers:  http://127.0.0.1:{args.port}/")
    print(f"Staff:      http://127.0.0.1:{args.port}/staff/")
    print(f"Wall board: http://127.0.0.1:{args.port}/board")
    if args.host == "0.0.0.0":
        ip = wifi_address()
        if ip:
            print(f"\nPhones on the same Wi-Fi: http://{ip}:{args.port}/")
            print(f"Open the staff page at http://{ip}:{args.port}/staff/ before printing the QR code.")
    print("\nPress Ctrl+C to stop.\n")
    app.run(host=args.host, port=args.port, debug=False, threaded=True)
