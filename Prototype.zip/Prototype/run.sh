#!/bin/sh
# Mac / Linux: sh run.sh   (sets everything up the first time, then starts the site)
cd "$(dirname "$0")"
[ -d .venv ] || python3 -m venv .venv
. .venv/bin/activate
pip install -q -r requirements.txt
python main.py --host 0.0.0.0
