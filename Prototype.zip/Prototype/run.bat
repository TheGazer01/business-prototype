@echo off
rem Double-click this file on Windows. It sets everything up the first time, then starts the site.
cd /d "%~dp0"
if not exist .venv (
    echo Setting up for the first time, this takes a minute...
    python -m venv .venv || (echo Python was not found. Install it from python.org and tick "Add Python to PATH". & pause & exit /b 1)
)
call .venv\Scripts\activate
pip install -q -r requirements.txt
start "" http://127.0.0.1:5000
python main.py --host 0.0.0.0
pause
