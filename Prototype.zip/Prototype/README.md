# Endfield's Cafe seat system (prototype)

Customers fill in the same 5 questions as the Google Form, get a ticket, and are called when a table
is ready. Staff see the floor, call guests, confirm arrivals and free tables.
Python (Flask) for the back end, HTML and CSS for the front end.

Easiest: on Windows double-click `run.bat` (Mac/Linux: `sh run.sh`). The first time it sets itself up,
then it opens the site. When it starts it prints a Wi-Fi address that phones can open.

By hand:

    pip install -r requirements.txt
    python main.py                     # http://127.0.0.1:5000
    python main.py --host 0.0.0.0      # let phones on your Wi-Fi open it (prints the address)
    python main.py --fresh             # ignore the saved line and start over with the demo crowd
    python main.py --empty             # ignore the saved line and start with every table free

Pages: `/` seat map, `/join` the form, `/ticket/<code>` a customer's ticket, `/board` the Now calling screen
for the cafe wall, `/team`, `/staff/` the dashboard, `/staff/manage` cafe name and team.

## Layout

    main.py                      starts the server
    backend/__init__.py          creates the app and registers the routes
    backend/core/matching.py     the form's answers, which table fits, wait estimates
    backend/core/store.py        tables, tickets, the line, calling, saving to data/state.json
    backend/core/settings.py     cafe name, address and team list (saved to data/settings.json)
    backend/routes/costumer.py   customer pages: seat map, join, ticket, board, team, QR, /api/status
    backend/routes/staff.py      staff dashboard actions, the name/team editor, CSV export
    frontend/templates/          base, home, join, ticket, board, team, staff, manage
    frontend/static/style.css    styling

## The form (same order and wording as the Google Form)

1. How many customers? 1 People, 2 People, 3 People, 4 or More
2. Preferred Seating Area: Window Side, Power Outlet / Study Corner, High Table, Couch Area, Any Available Spot
3. Primary Purpose of Visit: Solo Study / Remote Work, Group Study / Project, Casual Dining / Coffee Catch-up, Quick Grab & Go
4. Estimated Duration of Stay: Less than 30 minutes, 30 to 60 minutes, 1 to 2 hours, More than 2 hours
5. Customer Name or Identifier

## How tickets are stored

Each submit becomes a ticket with a 4-letter code (`join` in `store.py`). The tickets, the line and the tables
are saved to `data/state.json` after every change, so a restart keeps them. Staff can download every ticket
as a spreadsheet at `/staff/tickets.csv` (answers, status, table, minutes waited, times called).

## How customers are called

1. The ticket is saved and the line is checked in order (`_assign_waiting`). A party that does not fit is skipped, not blocked.
2. When a table fits, it is held for 10 minutes and the customer is called automatically: their ticket page
   shows "We are calling you", and their name and table appear on `/board`.
3. Staff can press "Call again" (counted on the ticket). "Guest arrived" starts their stay. "No-show" gives the table to the next party.
4. A waiting customer can switch to "Any Available Spot" from their ticket page.

## How a table is matched

- Seating area is a hard rule: Window Side only uses window tables, and so on.
- Among the free tables that fit, the one that wastes the fewest seats wins.
- With "Any Available Spot", the purpose decides which areas are tried first (solo study: study corner, group study:
  study corner and high table, casual: couch area and window, grab and go: high table and window).
- "4 or More" is treated as a group of 4. Staff can put tables together for bigger groups.
- The wait estimate walks the line and uses the stay times guests chose (walk-ins staff seat are assumed to stay 60 minutes).

## If it does not work

- `No module named flask`: run `pip install -r requirements.txt` (or use `run.bat`).
- A phone cannot open the site: start with `--host 0.0.0.0`, use the Wi-Fi address it prints, and make sure both are on the same Wi-Fi. If Windows asks about the firewall, allow Python on private networks.
- Port 5000 is busy: use `python main.py --port 5050`.

## Limits of this prototype

The staff pages have no login. Delete the `data` folder to reset everything, including the team list.
