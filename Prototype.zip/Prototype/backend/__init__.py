"""Endfield's Cafe seat system: app factory."""
import os
from pathlib import Path

from flask import Flask

from .core.settings import Settings
from .core.store import Store

ROOT = Path(__file__).resolve().parent.parent


def create_app(demo=True, settings_path=None, state_path=None, fresh=False):
    app = Flask(
        __name__,
        template_folder=str(ROOT / "frontend" / "templates"),
        static_folder=str(ROOT / "frontend" / "static"),
    )
    # Only used to sign the one-time messages shown after a form. Change it if you deploy this.
    app.secret_key = os.environ.get("SECRET_KEY", "endfield-dev-only")
    app.config["STORE"] = Store(demo=demo, fresh=fresh, state_path=state_path or ROOT / "data" / "state.json")
    app.config["SETTINGS"] = Settings(settings_path or ROOT / "data" / "settings.json")

    from .routes import costumer, staff
    app.register_blueprint(costumer.bp)
    app.register_blueprint(staff.bp, url_prefix="/staff")

    @app.context_processor
    def shop_info():
        """The cafe name and address are read on every page, so a rename shows up everywhere."""
        data = app.config["SETTINGS"].get()
        return {"shop_name": data["shop_name"], "shop_address": data["shop_address"]}

    return app
