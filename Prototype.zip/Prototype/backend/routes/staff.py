"""Staff dashboard: see the floor, confirm arrivals, free tables, seat walk-ins."""
import csv
import io

from flask import Blueprint, Response, current_app, flash, redirect, render_template, request, url_for

bp = Blueprint("staff", __name__)


def store():
    return current_app.config["STORE"]


def _run(action, *args, success=None):
    """Run a store action, show its result as a message, and go back to the dashboard."""
    try:
        action(*args)
        if success:
            flash(success, "ok")
    except ValueError as error:
        flash(str(error), "error")
    return redirect(url_for("staff.dashboard"))


@bp.get("/")
def dashboard():
    return render_template("staff.html", s=store().snapshot())


@bp.post("/ticket/<code>/arrived")
def arrived(code):
    return _run(store().arrived, code.upper(), success=f"Ticket {code.upper()} is seated.")


@bp.post("/ticket/<code>/call")
def call(code):
    return _run(store().call_again, code.upper(), success=f"Called {code.upper()} again. The board and their ticket page are updated.")


@bp.post("/ticket/<code>/cancel")
def cancel(code):
    return _run(store().cancel, code.upper(), success=f"Ticket {code.upper()} is cancelled.")


@bp.post("/table/<table_id>/walkin")
def walkin(table_id):
    return _run(store().seat_walkin, table_id, success=f"Table {table_id} is now occupied.")


@bp.post("/table/<table_id>/free")
def free(table_id):
    return _run(store().free_table, table_id, success=f"Table {table_id} is free.")


@bp.post("/table/<table_id>/release")
def release(table_id):
    return _run(store().release_hold, table_id, success=f"Hold on {table_id} released.")


def _settings():
    return current_app.config["SETTINGS"]


def _manage(action, *args, success=None):
    """Same as _run, but returns to the editing page so the person keeps their place."""
    try:
        action(*args)
        if success:
            flash(success, "ok")
    except ValueError as error:
        flash(str(error), "error")
    return redirect(url_for("staff.manage"))


@bp.get("/manage")
def manage():
    return render_template("manage.html", data=_settings().get())


@bp.post("/manage/cafe")
def save_cafe():
    return _manage(_settings().set_cafe, request.form.get("shop_name"), request.form.get("shop_address"),
                   success="The cafe name is saved.")


@bp.post("/manage/members/add")
def add_member():
    return _manage(_settings().add_member, request.form.get("name"), request.form.get("role"),
                   success="Added to the team.")


@bp.post("/manage/members/<int:member_id>/save")
def save_member(member_id):
    return _manage(_settings().update_member, member_id, request.form.get("name"), request.form.get("role"),
                   success="Saved.")


@bp.post("/manage/members/<int:member_id>/remove")
def remove_member(member_id):
    return _manage(_settings().delete_member, member_id, success="Removed from the team.")


@bp.get("/tickets.csv")
def export():
    """Every ticket as a spreadsheet file (open it in Excel or Google Sheets)."""
    rows = store().export_rows()
    out = io.StringIO()
    writer = csv.DictWriter(out, fieldnames=list(rows[0]) if rows else ["code"])
    writer.writeheader()
    writer.writerows(rows)
    return Response(out.getvalue(), mimetype="text/csv",
                    headers={"Content-Disposition": "attachment; filename=tickets.csv"})


@bp.post("/reset")
def reset():
    store().reset(demo=request.form.get("mode") == "demo")
    flash("The cafe was reset.", "ok")
    return redirect(url_for("staff.dashboard"))
