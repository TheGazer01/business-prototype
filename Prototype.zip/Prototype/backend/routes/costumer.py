"""Pages for customers: seat map, the join form, the ticket page, and the Now calling board."""
import io

from flask import Blueprint, current_app, flash, jsonify, redirect, render_template, request, send_file, url_for

from ..core import matching

bp = Blueprint("customer", __name__)


def store():
    return current_app.config["STORE"]


@bp.get("/")
def home():
    return render_template("home.html", s=store().snapshot())


@bp.route("/join", methods=["GET", "POST"])
def join():
    """The same 5 questions as the Google Form, in the same order."""
    if request.method == "POST":
        try:
            ticket = store().join(request.form.get("name"), request.form.get("party"), request.form.get("area"),
                                  request.form.get("purpose"), request.form.get("duration"))
        except ValueError as error:
            flash(str(error), "error")
        else:
            return redirect(url_for("customer.ticket", code=ticket.code))
    return render_template(
        "join.html", s=store().snapshot(), form=request.form,
        parties=[(key, label) for key, (label, _) in matching.PARTIES.items()],
        areas=matching.AREAS.items(), purposes=matching.PURPOSES.items(),
        durations=[(key, label) for key, (label, _) in matching.DURATIONS.items()],
    )


@bp.get("/ticket/<code>")
def ticket(code):
    code = code.upper()
    found = store().get_ticket(code)
    s = store().snapshot()
    if found is None:
        return render_template("ticket.html", ticket=None, s=s), 404
    return render_template("ticket.html", ticket=found, s=s, position=store().queue_position(code))


@bp.post("/ticket/<code>/cancel")
def cancel(code):
    try:
        store().cancel(code.upper())
        flash("Your ticket is cancelled.", "ok")
    except ValueError as error:
        flash(str(error), "error")
    return redirect(url_for("customer.ticket", code=code.upper()))


@bp.post("/ticket/<code>/any-table")
def any_table(code):
    try:
        store().relax_area(code.upper())
    except ValueError as error:
        flash(str(error), "error")
    return redirect(url_for("customer.ticket", code=code.upper()))


@bp.get("/board")
def board():
    """A screen for the cafe wall: who is being called right now, and who is next."""
    return render_template("board.html", s=store().snapshot())


@bp.get("/team")
def team():
    return render_template("team.html", members=current_app.config["SETTINGS"].get()["members"])


@bp.get("/api/status")
def api_status():
    """The same live numbers as JSON, so another screen or the POS can read them."""
    s = store().snapshot()
    return jsonify(
        free_seats=s["free_seats"], free_tables=s["free_tables"], percent_full=s["percent_full"],
        waiting=len(s["waiting"]),
        calling=[{"code": t.code, "name": t.name, "table": t.table_id} for t in s["assigned"]],
        tables=[{"id": t.id, "zone": t.zone, "seats": t.seats, "status": t.status} for t in s["tables"]],
    )


@bp.get("/qr.png")
def qr():
    """QR code that opens the join page. Print it for the entrance."""
    try:
        import qrcode
    except ImportError:
        return "Install the qrcode package (pip install qrcode[pil]) to see the QR code.", 501
    image = qrcode.make(url_for("customer.join", _external=True))
    buffer = io.BytesIO()
    image.save(buffer, format="PNG")
    buffer.seek(0)
    return send_file(buffer, mimetype="image/png")
