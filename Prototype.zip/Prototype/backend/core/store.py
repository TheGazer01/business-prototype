"""Tables, tickets, the waiting line, and calling customers.

Every change is saved to a small JSON file (data/state.json), so the line and the
tables are still there after the server restarts. One lock guards every change because
Flask's development server handles requests on several threads.
"""
import json
import os
import secrets
import threading
import time
from dataclasses import asdict, dataclass, field, replace
from functools import wraps
from pathlib import Path
from typing import Optional

from . import matching

HOLD_SECONDS = 10 * 60          # how long a called customer's table is held
CODE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"   # no 0/O or 1/I to avoid mix-ups

# The floor plan on a 640 x 460 canvas: (id, seats, zone, x, y, w, h)
LAYOUT = [
    ("W1", 1, "window", 30, 62, 40, 40), ("W2", 1, "window", 82, 62, 40, 40),
    ("W3", 2, "window", 134, 62, 80, 48), ("W4", 2, "window", 228, 62, 80, 48),
    ("S1", 2, "study", 346, 62, 80, 50), ("S2", 2, "study", 436, 62, 80, 50), ("S3", 4, "study", 526, 62, 88, 50),
    ("H1", 4, "high", 30, 182, 160, 44), ("H2", 2, "high", 30, 236, 100, 40),
    ("T1", 2, "floor", 236, 184, 70, 48), ("T2", 2, "floor", 314, 184, 70, 48), ("T3", 4, "floor", 238, 244, 146, 40),
    ("C1", 4, "couch", 424, 252, 100, 52), ("C2", 6, "couch", 424, 184, 184, 56), ("C3", 2, "couch", 536, 252, 72, 52),
]
ZONE_BOXES = [   # (key, label, x, y, w, h)
    ("window", "Window side", 16, 30, 300, 96),
    ("study", "Study corner (outlets)", 332, 30, 292, 96),
    ("high", "High table", 16, 146, 190, 140),
    ("floor", "Main floor", 222, 146, 170, 150),
    ("couch", "Couch area", 408, 146, 216, 170),
]
ZONE_LABELS = {key: label for key, label, *_ in ZONE_BOXES}

# Walk-ins already sitting when the demo starts: (table, minutes they plan to stay, minutes ago they sat)
DEMO_SEATED = [("W1", 30, 12), ("W3", 60, 25), ("S1", 120, 50), ("H2", 60, 10), ("T1", 60, 40), ("C1", 120, 20)]


@dataclass
class Table:
    id: str
    seats: int
    zone: str
    x: int
    y: int
    w: int
    h: int
    status: str = "free"       # free | held | occupied
    ticket_code: Optional[str] = None
    since: float = field(default_factory=time.time)
    stay_minutes: int = matching.DEFAULT_STAY

    @property
    def outlet(self):
        return self.zone == "study"

    @property
    def zone_label(self):
        return ZONE_LABELS[self.zone]


@dataclass
class Ticket:
    code: str
    name: str
    party: int
    party_key: str
    area: str
    purpose: str
    duration: str
    created: float
    status: str = "waiting"    # waiting | assigned | seated | done | cancelled | expired
    table_id: Optional[str] = None
    assigned_at: Optional[float] = None
    called_at: Optional[float] = None
    call_count: int = 0
    seated_at: Optional[float] = None
    left_at: Optional[float] = None

    party_label = property(lambda self: matching.PARTIES[self.party_key][0])
    area_label = property(lambda self: matching.AREAS[self.area])
    purpose_label = property(lambda self: matching.PURPOSES[self.purpose])
    duration_label = property(lambda self: matching.DURATIONS[self.duration][0])
    stay_minutes = property(lambda self: matching.DURATIONS[self.duration][1])

    def hold_left(self):
        """Seconds left on the table hold (0 when there is no hold)."""
        if self.status != "assigned" or self.assigned_at is None:
            return 0
        return max(0, int(HOLD_SECONDS - (time.time() - self.assigned_at)))


def _guarded(save):
    """Lock, drop expired holds first, run the method, and save the state if it changes something."""
    def decorate(method):
        @wraps(method)
        def wrapper(self, *args, **kwargs):
            with self._lock:
                self._expire_holds()
                result = method(self, *args, **kwargs)
                if save:
                    self._save()
                return result
        return wrapper
    return decorate


_reads = _guarded(save=False)
_writes = _guarded(save=True)


class Store:
    def __init__(self, demo=True, state_path=None, fresh=False):
        self._lock = threading.RLock()
        self._path = Path(state_path) if state_path else None
        if fresh or not self._load():
            self.reset(demo)

    # ---------- setup ----------
    def reset(self, demo=True):
        with self._lock:
            self._tables = {row[0]: Table(*row) for row in LAYOUT}
            self._tickets = {}
            self._line = []                    # ticket codes in the order they joined
            if demo:
                for table_id, stay, ago in DEMO_SEATED:
                    t = self._tables[table_id]
                    t.status, t.stay_minutes, t.since = "occupied", stay, time.time() - ago * 60
            self._save()

    # ---------- reading ----------
    @_reads
    def snapshot(self):
        """A copy of everything the pages need, so templates never touch live objects."""
        now = time.time()
        tables = [replace(t) for t in self._tables.values()]
        tickets = [replace(self._tickets[c]) for c in self._line]
        waiting = [t for t in tickets if t.status == "waiting"]
        assigned = [t for t in tickets if t.status == "assigned"]
        free = [t for t in tables if t.status == "free"]
        total_seats = sum(t.seats for t in tables)
        free_seats = sum(t.seats for t in free)
        waits = {code: matching.wait_text(s) for code, s in matching.estimate_waits(tables, waiting, now).items()}
        zones = [{"key": k, "label": label, "x": x, "y": y, "w": w, "h": h,
                  "free": sum(1 for t in free if t.zone == k),
                  "total": sum(1 for t in tables if t.zone == k)}
                 for k, label, x, y, w, h in ZONE_BOXES]
        return {
            "tables": tables, "zones": zones, "waiting": waiting, "waits": waits,
            "assigned": sorted(assigned, key=lambda t: t.called_at, reverse=True),
            "frees": {t.id: matching.wait_text(matching.free_at(t, now) - now) for t in tables if t.status != "free"},
            "free_seats": free_seats, "free_tables": len(free), "total_tables": len(tables),
            "percent_full": round(100 * (total_seats - free_seats) / total_seats),
            "hold_minutes": HOLD_SECONDS // 60,
        }

    @_reads
    def get_ticket(self, code):
        ticket = self._tickets.get(str(code).upper())
        return replace(ticket) if ticket else None

    @_reads
    def queue_position(self, code):
        """1 = next in line. None if the ticket is not waiting."""
        waiting = [c for c in self._line if self._tickets[c].status == "waiting"]
        return waiting.index(code) + 1 if code in waiting else None

    @_reads
    def export_rows(self):
        """One row per ticket, ready for a spreadsheet (this is the data your research team can study)."""
        def clock(stamp):
            return time.strftime("%Y-%m-%d %H:%M", time.localtime(stamp)) if stamp else ""
        rows = []
        for code in self._line:
            t = self._tickets[code]
            waited = round((t.seated_at - t.created) / 60) if t.seated_at else ""
            rows.append({
                "code": t.code, "name": t.name, "customers": t.party_label, "seating_area": t.area_label,
                "purpose": t.purpose_label, "duration": t.duration_label, "status": t.status,
                "table": t.table_id or "", "joined_at": clock(t.created), "waited_minutes": waited,
                "times_called": t.call_count,
            })
        return rows

    # ---------- customer actions ----------
    @_writes
    def join(self, name, party, area, purpose, duration):
        """Store a new ticket from the 5 form answers, then try to seat it straight away."""
        data = matching.clean_request(name, party, area, purpose, duration)
        if not matching.fits_somewhere(self._tables.values(), data["party"], data["area"]):
            raise ValueError(f"{matching.AREAS[data['area']]} has no table for "
                             f"{matching.PARTIES[data['party_key']][0].lower()}. Please pick another seating area.")
        code = self._new_code()
        self._tickets[code] = Ticket(code=code, created=time.time(), **data)
        self._line.append(code)
        self._assign_waiting()
        return replace(self._tickets[code])

    @_writes
    def cancel(self, code):
        ticket = self._tickets.get(code)
        if ticket is None or ticket.status not in ("waiting", "assigned"):
            raise ValueError("That ticket can no longer be cancelled.")
        self._close_ticket(ticket, "cancelled")
        self._assign_waiting()

    @_writes
    def relax_area(self, code):
        """A waiting customer decides to take any available spot instead of their chosen area."""
        ticket = self._tickets.get(code)
        if ticket is None or ticket.status != "waiting":
            raise ValueError("Only a ticket that is still waiting can change its seating area.")
        ticket.area = "any"
        self._assign_waiting()

    # ---------- calling customers ----------
    @_writes
    def call_again(self, code):
        """Staff call the customer once more (the ticket page and the Now calling board both update)."""
        ticket = self._tickets.get(code)
        if ticket is None or ticket.status != "assigned":
            raise ValueError("That ticket has no table ready to call for.")
        ticket.call_count += 1
        ticket.called_at = time.time()

    # ---------- staff actions ----------
    @_writes
    def arrived(self, code):
        """The guest showed up: the held table becomes occupied and the stay clock starts."""
        ticket = self._tickets.get(code)
        if ticket is None or ticket.status != "assigned":
            raise ValueError("That ticket has no held table.")
        table = self._tables[ticket.table_id]
        table.status, table.since = "occupied", time.time()
        ticket.status, ticket.seated_at = "seated", time.time()

    @_writes
    def seat_walkin(self, table_id):
        table = self._table(table_id)
        if table.status != "free":
            raise ValueError(f"Table {table_id} is not free.")
        table.status, table.ticket_code, table.since = "occupied", None, time.time()
        table.stay_minutes = matching.DEFAULT_STAY

    @_writes
    def free_table(self, table_id):
        """Guests left: the table is free and the line moves."""
        table = self._table(table_id)
        if table.status != "occupied":
            raise ValueError(f"Table {table_id} is not occupied.")
        ticket = self._tickets.get(table.ticket_code or "")
        if ticket and ticket.status == "seated":
            ticket.status, ticket.left_at = "done", time.time()
        table.status, table.ticket_code, table.since = "free", None, time.time()
        self._assign_waiting()

    @_writes
    def release_hold(self, table_id):
        """No-show: give up the hold so the next party can have the table."""
        table = self._table(table_id)
        ticket = self._tickets.get(table.ticket_code or "")
        if table.status != "held" or ticket is None:
            raise ValueError(f"Table {table_id} is not on hold.")
        self._close_ticket(ticket, "expired")
        self._assign_waiting()

    # ---------- internals (always called with the lock held) ----------
    def _table(self, table_id):
        table = self._tables.get(table_id)
        if table is None:
            raise ValueError("There is no such table.")
        return table

    def _new_code(self):
        while True:
            code = "".join(secrets.choice(CODE_ALPHABET) for _ in range(4))
            if code not in self._tickets:
                return code

    def _close_ticket(self, ticket, status):
        if ticket.table_id:
            table = self._tables[ticket.table_id]
            if table.status == "held" and table.ticket_code == ticket.code:
                table.status, table.ticket_code, table.since = "free", None, time.time()
        ticket.status = status

    def _expire_holds(self):
        expired = [t for t in self._tickets.values() if t.status == "assigned" and t.hold_left() == 0]
        for ticket in expired:
            self._close_ticket(ticket, "expired")
        if expired:
            self._assign_waiting()
            self._save()

    def _assign_waiting(self):
        """Walk the line in order. Every party that now fits gets a held table and is called.

        A party that does not fit is skipped, not blocked, so a group waiting for the couch
        area does not stop a solo guest from taking a free window stool.
        """
        for code in self._line:
            ticket = self._tickets[code]
            if ticket.status != "waiting":
                continue
            table = matching.best_table(self._tables.values(), ticket.party, ticket.area, ticket.purpose)
            if table is None:
                continue
            now = time.time()
            table.status, table.ticket_code, table.since = "held", code, now
            table.stay_minutes = ticket.stay_minutes
            ticket.status, ticket.table_id, ticket.assigned_at = "assigned", table.id, now
            ticket.called_at, ticket.call_count = now, 1       # the first call goes out automatically

    # ---------- saving ----------
    def _save(self):
        if self._path is None:
            return
        data = {"tables": [asdict(t) for t in self._tables.values()],
                "tickets": [asdict(self._tickets[c]) for c in self._line], "line": self._line}
        self._path.parent.mkdir(parents=True, exist_ok=True)
        temp = self._path.with_suffix(".tmp")
        temp.write_text(json.dumps(data, indent=1), encoding="utf-8")
        os.replace(temp, self._path)     # one step, so a crash never leaves a half-written file

    def _load(self):
        """Load the saved state. False when there is none (or it cannot be read), so we start fresh."""
        if self._path is None or not self._path.exists():
            return False
        try:
            data = json.loads(self._path.read_text(encoding="utf-8"))
            tables = {d["id"]: Table(**d) for d in data["tables"]}
            tickets = {d["code"]: Ticket(**d) for d in data["tickets"]}
            if set(tables) != {row[0] for row in LAYOUT}:
                return False             # the floor plan changed since the file was saved
        except (OSError, ValueError, KeyError, TypeError):
            return False
        self._tables, self._tickets, self._line = tables, tickets, [c for c in data["line"] if c in tickets]
        return True
