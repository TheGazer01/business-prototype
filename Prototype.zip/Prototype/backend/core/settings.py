"""Cafe name, address and team list. Saved to a small JSON file so edits survive a restart.

The seat state (tables and tickets) stays in memory; only these settings are written to disk.
"""
import json
import os
import threading
from pathlib import Path

MAX_MEMBERS = 20
DEFAULTS = {
    "shop_name": "Endfield's Cafe",
    "shop_address": "Talos II, OMV Dijiang",
    "members": [
        {"id": 1, "name": "Euodiaz Bacuyag", "role": "Finance manager"},
        {"id": 2, "name": "Ivy Suzzaine Gregorio", "role": "Product/MVP lead"},
        {"id": 3, "name": "Miguel John Guarin", "role": "Project manager"},
        {"id": 4, "name": "Kian Angelo Natividad", "role": "Marketing head"},
        {"id": 5, "name": "Hans Martin Valdez", "role": "Research head"},
    ],
    "next_id": 6,
}


def _clean(text, label, limit, required=True):
    text = " ".join(str(text or "").split())
    if required and not text:
        raise ValueError(f"Please enter the {label}.")
    if len(text) > limit:
        raise ValueError(f"Please keep the {label} under {limit} characters.")
    return text


class Settings:
    def __init__(self, path):
        self._path = Path(path)
        self._lock = threading.RLock()
        self._data = self._load()

    # ---------- reading ----------
    def get(self):
        with self._lock:
            return json.loads(json.dumps(self._data))      # a safe copy

    # ---------- changing ----------
    def set_cafe(self, name, address):
        with self._lock:
            self._data["shop_name"] = _clean(name, "cafe name", 40)
            self._data["shop_address"] = _clean(address, "address", 80, required=False)
            self._save()

    def add_member(self, name, role):
        with self._lock:
            if len(self._data["members"]) >= MAX_MEMBERS:
                raise ValueError(f"The list is full ({MAX_MEMBERS} people). Remove someone first.")
            member = {"id": self._data["next_id"], "name": _clean(name, "name", 40),
                      "role": _clean(role, "role", 60, required=False)}
            self._data["next_id"] += 1
            self._data["members"].append(member)
            self._save()

    def update_member(self, member_id, name, role):
        with self._lock:
            member = self._find(member_id)
            member["name"] = _clean(name, "name", 40)
            member["role"] = _clean(role, "role", 60, required=False)
            self._save()

    def delete_member(self, member_id):
        with self._lock:
            self._data["members"].remove(self._find(member_id))
            self._save()

    # ---------- internals ----------
    def _find(self, member_id):
        for member in self._data["members"]:
            if member["id"] == member_id:
                return member
        raise ValueError("That person is not on the list.")

    def _load(self):
        try:
            data = json.loads(self._path.read_text(encoding="utf-8"))
            return {**json.loads(json.dumps(DEFAULTS)), **data}
        except (OSError, ValueError):
            return json.loads(json.dumps(DEFAULTS))      # no file yet, or it is unreadable

    def _save(self):
        self._path.parent.mkdir(parents=True, exist_ok=True)
        temp = self._path.with_suffix(".tmp")
        temp.write_text(json.dumps(self._data, indent=2, ensure_ascii=False), encoding="utf-8")
        os.replace(temp, self._path)       # replace in one step so a crash never leaves half a file
