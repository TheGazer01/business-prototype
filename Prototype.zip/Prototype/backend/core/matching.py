"""Matching rules: the form's answers, which table fits, and how long a party will wait.

Everything here is a pure function (no state, no Flask), so the rules are
easy to read, test and change. The answers mirror the 5 questions of the
Google Form, in the same order and wording.
"""
import math

# Question 1: How many customers?  key -> (label shown, seats needed)
PARTIES = {"1": ("1 People", 1), "2": ("2 People", 2), "3": ("3 People", 3), "4+": ("4 or More", 4)}

# Question 2: Preferred Seating Area. The keys match the zone names on the floor plan.
AREAS = {
    "window": "Window Side",
    "study": "Power Outlet / Study Corner",
    "high": "High Table",
    "couch": "Couch Area",
    "any": "Any Available Spot",
}

# Question 3: Primary Purpose of Visit
PURPOSES = {
    "solo": "Solo Study / Remote Work",
    "group": "Group Study / Project",
    "casual": "Casual Dining / Coffee Catch-up",
    "grab": "Quick Grab & Go",
}

# Question 4: Estimated Duration of Stay.  key -> (label shown, minutes we plan for)
DURATIONS = {
    "lt30": ("Less than 30 minutes", 30),
    "30to60": ("30 to 60 minutes", 60),
    "1to2h": ("1 to 2 hours", 120),
    "gt2h": ("More than 2 hours", 180),
}

# When a guest says "Any Available Spot", their purpose decides which areas we try first.
PURPOSE_ZONES = {
    "solo": ["study", "window"],
    "group": ["study", "high"],
    "casual": ["couch", "window"],
    "grab": ["high", "window"],
}
DEFAULT_STAY = 60       # minutes we assume for walk-ins that staff seat without a ticket


def clean_request(name, party, area, purpose, duration):
    """Check the 5 answers in form order. Returns a dict, or raises ValueError with a friendly message."""
    if party not in PARTIES:
        raise ValueError("Question 1 is required. Please choose how many customers.")
    if area not in AREAS:
        raise ValueError("Question 2 is required. Please choose a seating area.")
    if purpose not in PURPOSES:
        raise ValueError("Question 3 is required. Please choose the purpose of your visit.")
    if duration not in DURATIONS:
        raise ValueError("Question 4 is required. Please choose how long you will stay.")
    name = " ".join(str(name or "").split())
    if not name:
        raise ValueError("Question 5 is required. Please enter your name or an identifier we can call out.")
    if len(name) > 40:
        raise ValueError("Please keep your name or identifier under 40 characters.")
    return {"name": name, "party_key": party, "party": PARTIES[party][1],
            "area": area, "purpose": purpose, "duration": duration}


def zone_ok(table, area):
    return area == "any" or table.zone == area


def fits_somewhere(tables, party, area):
    """True if at least one table, free or not, could ever seat this party in this area."""
    return any(t.seats >= party and zone_ok(t, area) for t in tables)


def is_eligible(table, party, area):
    return table.status == "free" and table.seats >= party and zone_ok(table, area)


def _fit_score(table, party, area, purpose):
    """Lower is better: seats wasted, plus a small penalty when the area is not one the purpose prefers."""
    rank = 0
    if area == "any":
        order = PURPOSE_ZONES.get(purpose, [])
        rank = order.index(table.zone) if table.zone in order else 2
    return (table.seats - party + rank, rank)


def best_table(tables, party, area, purpose):
    """Pick the free table that wastes the fewest seats. None when nothing fits right now."""
    options = [t for t in tables if is_eligible(t, party, area)]
    if not options:
        return None
    return min(options, key=lambda t: (*_fit_score(t, party, area, purpose), t.id))


def free_at(table, now):
    """When this table is expected to be free (a timestamp)."""
    if table.status == "free":
        return now
    if table.status == "held":
        return now + table.stay_minutes * 60        # assume the guest arrives about now
    return max(table.since + table.stay_minutes * 60, now + 300)   # overdue guests: about 5 more minutes


def estimate_waits(tables, waiting, now):
    """Walk the line in order and work out when each waiting party should get a table.

    Each party "uses up" the table it would get for the length of stay it chose, so the
    people behind them see a longer wait. Returns {ticket code: seconds, or None if unknown}.
    """
    available = {t.id: free_at(t, now) for t in tables}
    result = {}
    for ticket in waiting:
        options = [t for t in tables if t.seats >= ticket.party and zone_ok(t, ticket.area)]
        if not options:
            result[ticket.code] = None
            continue
        pick = min(options, key=lambda t: (available[t.id],
                                           *_fit_score(t, ticket.party, ticket.area, ticket.purpose), t.id))
        result[ticket.code] = max(0, available[pick.id] - now)
        available[pick.id] = max(available[pick.id], now) + DURATIONS[ticket.duration][1] * 60
    return result


def wait_text(seconds):
    """Turn seconds into words a customer can read. It is an estimate, so we round up to 5 minutes."""
    if seconds is None:
        return "We cannot estimate this one yet"
    if seconds <= 120:
        return "a few minutes"
    minutes = 5 * math.ceil(seconds / 60 / 5)
    hours, rest = divmod(minutes, 60)
    if hours and rest:
        return f"about {hours} hour{'s' if hours > 1 else ''} {rest} minutes"
    if hours:
        return f"about {hours} hour{'s' if hours > 1 else ''}"
    return f"about {minutes} minutes"
